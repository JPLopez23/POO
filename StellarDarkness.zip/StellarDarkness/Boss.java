import greenfoot.*;

public class Boss extends Actor {
    private GifImage myGif = new GifImage("Boss.gif");
    private int maxHealth = 100;
    private int currentHealth = maxHealth;

    // Declarar un objeto de tipo Counter para mostrar la vida del jefe
    private Counter bossHealthCounter;

    public Boss() {
        bossHealthCounter = new Counter("Boss Health: ");
        bossHealthCounter.setValue(currentHealth); // Inicializar el contador con la vida actual
    }

    public void addedToWorld(World world) {
        // Agregar el contador de vida del jefe al mundo
        world.addObject(bossHealthCounter, 380, 50);
    }

    public void act() {
        setImage(myGif.getCurrentImage());
        launchMissile();
    }

    public void receiveDamage(int damage) {
        currentHealth -= damage;
        bossHealthCounter.setValue(currentHealth); // Actualizar el contador de vida

        if (currentHealth <= 0) {
            defeatBoss();
        }
    }

    private void launchMissile() {
        if (Greenfoot.getRandomNumber(100) < 1) { // Ajusta la probabilidad según tu preferencia
            int targetX = getWorld().getObjects(Nav.class).get(0).getX();
            int targetY = getWorld().getObjects(Nav.class).get(0).getY();
            BossMissile missile = new BossMissile(targetX, targetY);
            getWorld().addObject(missile, getX(), getY());
        }
    }

    private void defeatBoss() {
        // Eliminar al jefe
        getWorld().removeObject(this);

        // Otorgar puntos por derrotar al jefe
        Level1Boss level = (Level1Boss) getWorld();
        level.bossDefeated();
    }
    
    // No es necesario declarar bossDefeated() aquí, ya se declara en la clase Level1Boss
}


