import greenfoot.*;

public class HasGanadoWorld extends World {
    private Counter totalPointsCounter;

    public HasGanadoWorld(int totalPoints) {
        super(760, 760, 1);
        totalPointsCounter = new Counter("Total Points: ");
        totalPointsCounter.setValue(totalPoints);
        addObject(totalPointsCounter, getWidth() / 2, getHeight() / 2);
        addObject(new Message("Has Ganado"), getWidth() / 2, getHeight() / 2 - 50);
        addObject(new Message("Presiona Enter para continuar"), getWidth() / 2, getHeight() / 2 + 50);
    }
    public void act() {
        if (Greenfoot.isKeyDown("enter")) {
            Greenfoot.setWorld(new menu()); // Cambiar al menú al presionar Enter
        }
    }
}

