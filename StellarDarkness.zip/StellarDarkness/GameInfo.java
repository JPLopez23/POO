public class GameInfo {
    private static int totalPoints = 0;
    private static int totalLives = 0;

    public static int getTotalPoints() {
        return totalPoints;
    }

    public static void setTotalPoints(int points) {
        totalPoints = points;
    }

    public static int getTotalLives() {
        return totalLives;
    }

    public static void setTotalLives(int lives) {
        totalLives = lives;
    }
}