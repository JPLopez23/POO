import greenfoot.*;

public class Level1 extends World {
    private int lives = 3;
    private int points = 0;
    private Counter livesCounter;
    private Counter pointsCounter;
    private GreenfootSound level1Music;

    public Level1() {
        super(760, 760, 1);
        livesCounter = new Counter("Lives: ");
        pointsCounter = new Counter("Points: ");
        addObject(livesCounter, 70, 720);
        addObject(pointsCounter, 680, 720);
        prepare();
        showStatus();
        level1Music = new GreenfootSound("level1.mp3");
        level1Music.playLoop();
    }
    private void prepare()
    {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 7; col++) {
                Enemy enemy = new Enemy();
                addObject(enemy, 75 + col * 100, 80 + row * 100);
            }
        }
        
        Nav nav = new Nav(this);
        addObject(nav, 380, 648);
        
        // Alinea los actores "Fire" en una línea debajo de la última fila de enemigos
        int lastEnemyY = 80 + 2 * 100; // Última fila de enemigos
        int fireY = lastEnemyY + 100; // Ajusta la posición vertical
        
        for (int i = 0; i < 3; i++) {
            Fire fire = new Fire();
            addObject(fire, 75 + i * 300, fireY);
        }
    }

    public void addPoints(int pointsToAdd) {
        points += pointsToAdd;
        showStatus();
    }

    public void decreaseLives()
    {
        lives--;
        showStatus(); // Actualiza los contadores cuando se reduce una vida
    }
    
    public int getLives()
    {
        return lives;
    }
    
    public int getPoints()
    {
        return points;
    }
    
    public void showStatus()
    {
        livesCounter.setValue(getLives());
        pointsCounter.setValue(getPoints());
    }
    
    public void stopped()
    {
        level1Music.stop();
    }
    // Verifica si no hay enemigos restantes en Level1
    public boolean noEnemiesLeft() {
        return getObjects(Enemy.class).isEmpty();
    }
    
    public void act()
    {
        // Verifica si no hay enemigos restantes en Level1 y cambia a Level1Boss
        if (noEnemiesLeft()) {
            // Guarda los valores en GameInfo antes de cambiar de nivel
            GameInfo.setTotalPoints(points);
            GameInfo.setTotalLives(lives);
            stopped();
            Greenfoot.setWorld(new Level1Boss());
        }
    }

}
