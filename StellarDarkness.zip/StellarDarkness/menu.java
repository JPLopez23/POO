import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class menu extends World
{
    flecha flecha = new flecha();
    private int opcion=0;
    /**
     * Constructor for objects of class menu.
     * 
     */
    public menu()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(760, 760, 1); 
        prepare();
    }
    private void prepare()
    {
        addObject (flecha, 275, 250) ;
        gametitulo gametitulo = new gametitulo();
        addObject(gametitulo,400,116);
        titulo1 titulo1 = new titulo1();
        addObject(titulo1,400,250);
        titulo2 titulo2 = new titulo2();
        addObject(titulo2,400,350);
    }
    public void act()
    {
        if (Greenfoot.isKeyDown ("UP") && opcion!=0) {opcion++; }
        if (Greenfoot.isKeyDown ("DOWN") && opcion!=1) {opcion--;}
        if (opcion>=2) opcion=0;
        if (opcion<0) opcion=1;
        
        flecha.setLocation(275, 250 +(opcion*100));
        
        if (Greenfoot.isKeyDown("SPACE")) {
            switch (opcion) {
                case 0: // Jugar
                    Greenfoot.setWorld(new Level1());
                    break;
                case 1: // Salir
                    Greenfoot.setWorld(new Level2());
                    break;
            }
        }
    }
}
