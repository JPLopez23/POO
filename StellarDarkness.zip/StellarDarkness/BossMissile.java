import greenfoot.*;

public class BossMissile extends Actor {
    private int speed = 5;
    private int targetX;
    private int targetY;
    private boolean followTarget = true;
    private int lifeTimeCounter = 0;
    private static final int LIFE_TIME = 120; // 60 actos aproximadamente para un segundo

    public BossMissile(int targetX, int targetY) {
        GreenfootImage missileImage = new GreenfootImage("MS.png");
        setImage(missileImage);
        this.targetX = targetX;
        this.targetY = targetY;
    }

    public void act() {
        lifeTimeCounter++; // Incrementa el contador de tiempo de vida

        if (followTarget) {
            moveTowardsTarget();
        } else {
            checkBoundary();
        }

        checkCollision();

        // Verifica si ha pasado el tiempo de vida y elimina el misil
        if (lifeTimeCounter >= LIFE_TIME) {
            getWorld().removeObject(this);
        }
    }
    public void checkCollision() {
        if (isTouching(Nav.class)) {
            Nav player = (Nav) getOneIntersectingObject(Nav.class);
            player.receiveDamage();
        }
    }

    private void moveTowardsTarget() {
        double angle = Math.atan2(targetY - getY(), targetX - getX());
        int dx = (int) (speed * Math.cos(angle));
        int dy = (int) (speed * Math.sin(angle));
        setLocation(getX() + dx, getY() + dy);
        
        double distance = Math.sqrt(Math.pow(targetX - getX(), 2) + Math.pow(targetY - getY(), 2));
        if (distance < 10) { // Ajusta la distancia según tu preferencia
            followTarget = false;
        }
    }   

    private void checkBoundary() {
        if (getX() <= 0 || getX() >= getWorld().getWidth() - 1 || getY() <= 0 || getY() >= getWorld().getHeight() - 1) {
            getWorld().removeObject(this);
        }
    }
}
