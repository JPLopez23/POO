import greenfoot.*;

public class Nav extends Actor {
    private GifImage myGif = new GifImage("nav.gif");
    private static final int SPEED = 4;
    private static final int TURN_AMOUNT = 3;
    private static final int SHOOT_DELAY = 300;
    private long lastShotTime = 0;
    private int invulnerabilityTime = 500;
    private long lastDamageTime = 0;
    private boolean isInvulnerable = false;
    private int damageCooldown = 0;
    private GreenfootSound lostLifeSound;

    public Nav(World world) {
        lostLifeSound = new GreenfootSound("lostLife.mp3");
    }

    public void act() {
        setImage(myGif.getCurrentImage());
        moveAndTurn();
        checkFire();
        checkCollisionWithEnemy();
        updateInvulnerability();
    }

    public void moveAndTurn() {
        int speed = 4;
        int turnAmount = 3;

        if (Greenfoot.isKeyDown("up")) setLocation(getX(), getY() - speed);
        if (Greenfoot.isKeyDown("down")) setLocation(getX(), getY() + speed);
        if (Greenfoot.isKeyDown("left")) setLocation(getX() - speed, getY());
        if (Greenfoot.isKeyDown("right")) setLocation(getX() + speed, getY());
        if (Greenfoot.isKeyDown("a")) turn(-turnAmount);
        if (Greenfoot.isKeyDown("d")) turn(turnAmount);
    }

    public void checkFire() {
        if (Greenfoot.isKeyDown("space") && canShoot()) {
            Bullet bullet = new Bullet();
            getWorld().addObject(bullet, getX(), getY());
            bullet.setRotation(270);
            lastShotTime = System.currentTimeMillis();
        }
    }

    private boolean canShoot() {
        return (System.currentTimeMillis() - lastShotTime) >= SHOOT_DELAY;
    }

    public void checkCollisionWithEnemy() {
        if (!isInvulnerable && (isTouching(Enemy.class) || isTouching(BossMissile.class))) {
            receiveDamage();
        }
    }

    public void receiveDamage() {
        long currentTime = System.currentTimeMillis();

        if ((currentTime - lastDamageTime) >= invulnerabilityTime) {
            World world = getWorld();
            if (world instanceof Level1) {
                Level1 level1 = (Level1) world;
                level1.decreaseLives();

                if (level1.getLives() <= 0) {
                    showGameOver(level1);
                }
            } else if (world instanceof Level1Boss) {
                Level1Boss level1Boss = (Level1Boss) world;
                level1Boss.decreaseLives();

                if (level1Boss.getLives() <= 0) {
                    showGameOver(level1Boss);
                }
            }

            isInvulnerable = true;
            damageCooldown = invulnerabilityTime;
            lastDamageTime = currentTime;

            // Reducir el volumen del sonido a la mitad
            lostLifeSound.setVolume(50);
            lostLifeSound.play();
        }
    }

    private void updateInvulnerability() {
        if (damageCooldown > 0) {
            damageCooldown--;
        } else {
            isInvulnerable = false;
        }
    }

    private void showGameOver(World world) {
        GreenfootImage gameOverImage = new GreenfootImage("Game Over", 72, Color.WHITE, new Color(0, 0, 0, 0));
        world.getBackground().drawImage(gameOverImage, world.getWidth() / 2 - gameOverImage.getWidth() / 2, world.getHeight() / 2 - gameOverImage.getHeight() / 2);
        Greenfoot.stop();
    }
}

