import greenfoot.*;

public class Enemy extends Actor {
    private int health = 5;
    private int speed = 2;
    private int moveDirection = 1;
    private int moveDistance = 30;
    private int moveCount = 0;

    public void act() {
        moveHorizontally();
        moveVertically();
        checkBoundaryCollision();
        checkCollision();
    }

    private void moveHorizontally() {
        setLocation(getX() + (moveDirection * speed), getY());
    }

    private void moveVertically() {
        moveCount++;
        if (moveCount >= moveDistance) {
            setLocation(getX(), getY() + 1);
            moveCount = 0;
        }
    }

    private void checkBoundaryCollision() {
        if (getX() <= 0 || getX() >= getWorld().getWidth() - 1) {
            moveDirection *= -1;
            setLocation(getX(), getY() + 10);
        }
    }

    public void receiveShot(int damageValue) {
        health -= damageValue;

        if (health <= 0) {
            eliminate();
            getWorld().removeObject(this);
        }
    }

    public void checkCollision() {
        if (isTouching(Nav.class)) {
            Nav player = (Nav) getOneIntersectingObject(Nav.class);
            player.receiveDamage();
        }
    }


    private void eliminate() {
        Level1 level = (Level1) getWorld();
        level.addPoints(100);
    }
}


