import greenfoot.*;

public class Level1Boss extends World {
    private Counter livesCounter;
    private Counter pointsCounter;
    private Counter bossHealthCounter; // Agregar el contador de vida del jefe
    private GreenfootSound level1bossMusic;
    public Level1Boss() {
        super(760, 760, 1);
        livesCounter = new Counter("Lives: ");
        pointsCounter = new Counter("Points: ");
        livesCounter.setValue(GameInfo.getTotalLives());
        pointsCounter.setValue(GameInfo.getTotalPoints());

        addObject(livesCounter, 70, 720);
        addObject(pointsCounter, 680, 720);

        prepare();
        
        level1bossMusic = new GreenfootSound("level1boss.mp3");
        level1bossMusic.playLoop();
    }

    private void prepare() {
        Nav nav = new Nav(this);
        addObject(nav, 380, 648);

        Boss boss = new Boss();
        addObject(boss, 380, 200);

        // Agregar los actores "Fire"
        int lastEnemyY = 80 + 2 * 100; // Última fila de enemigos
        int fireY = lastEnemyY + 100; // Ajustar la posición vertical

        for (int i = 0; i < 3; i++) {
            Fire fire = new Fire();
            addObject(fire, 75 + i * 300, fireY);
        }
    }

    public void bossDefeated() {
        int currentPoints = GameInfo.getTotalPoints();
        GameInfo.setTotalPoints(currentPoints + 1000);
        stopped();
        Greenfoot.setWorld(new HasGanadoWorld(GameInfo.getTotalPoints())); // Cambiar al mundo "HasGanadoWorld"
    }

    public int getLives() {
        return GameInfo.getTotalLives();
    }

    public void decreaseLives() {
        GameInfo.setTotalLives(GameInfo.getTotalLives() - 1);
        livesCounter.setValue(GameInfo.getTotalLives());
    }
    public void stopped()
        {
            level1bossMusic.stop();
        }
}






