import greenfoot.*;

public class Message extends Actor {
    public Message(String text) {
        GreenfootImage image = new GreenfootImage(text, 36, Color.WHITE, new Color(0, 0, 0, 0));
        setImage(image);
    }
}

