import greenfoot.*;

public class Bullet extends Actor {
    private static final int SPEED = 10;
    private int damageValue = 1;

    public void act() {
        move(SPEED);
        checkCollision();
    }

    public void checkCollision() {
        // Verificar colisión con enemigos y jefe
        Enemy enemy = (Enemy) getOneIntersectingObject(Enemy.class);
        Boss boss = (Boss) getOneIntersectingObject(Boss.class);

        if (enemy != null) {
            enemy.receiveShot(damageValue);
            getWorld().removeObject(this);
        }

        if (boss != null) {
            boss.receiveDamage(damageValue);
            getWorld().removeObject(this);
        }
    }
}















