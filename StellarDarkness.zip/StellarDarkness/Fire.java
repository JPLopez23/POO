import greenfoot.*;

public class Fire extends Actor {
    private int damageValue = 1;

    public void act() {
        moveAround();
    }

    public void moveAround() {
        move(4);
        if (Greenfoot.getRandomNumber(100) < 10) {
            turn(Greenfoot.getRandomNumber(90) - 45);
        }
    
        int minX = 5;
        int maxX = getWorld().getWidth() - 5;
        int minY = 5;
        int maxY = getWorld().getHeight() - 5;
    
        if (getX() <= minX || getX() >= maxX || getY() <= minY || getY() >= maxY) {
            turn(180);
        }
    
        checkCollisionWithNav();
    }

    private void checkCollisionWithNav() {
        if (!isTouching(Nav.class)) {
            return; // No colisiona con Nav, no hace nada
        }
        
        Nav player = (Nav) getOneIntersectingObject(Nav.class);
        player.receiveDamage();
    }

}



