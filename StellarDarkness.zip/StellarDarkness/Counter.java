import greenfoot.*;

public class Counter extends Actor {
    private String prefix;
    private int value;

    public Counter(String prefix) {
        this.prefix = prefix;
        this.value = 0;
        updateImage();
    }

    public void setValue(int value) {
        this.value = value;
        updateImage();
    }

    public int getValue() {
        return value;
    }

    private void updateImage() {
        GreenfootImage image = new GreenfootImage(prefix + value, 24, Color.WHITE, new Color(0, 0, 0, 0));
        setImage(image);
    }
}


